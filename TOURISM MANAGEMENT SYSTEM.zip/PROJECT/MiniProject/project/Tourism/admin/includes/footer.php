<div class="copyrights">
	 <p>© 2020 TMS. All Rights Reserved |  <a href="#">TMS</a> </p>
</div>	
